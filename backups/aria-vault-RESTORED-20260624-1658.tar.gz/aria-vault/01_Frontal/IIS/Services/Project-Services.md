---
brain_region: frontal-iis
type: stub
created: 2026-06-19
---

# Project Services

> Stub created by link-web.mjs. First references came from another note — populate when ready.

<!-- LINK-WEB:auto -->
<!-- /LINK-WEB:auto -->

## Related

<!-- LINK-WEB:auto -->
- [[AXIS]]
- [[Ahmad]]
- [[Backup-agent]]
- [[Brain-Map]]
- [[Claude-Code]]
- [[Cleaning-agent]]
- [[Codex]]
- [[Cowork]]
- [[Customers]]
- [[DIRECTOR_AUTONOMY]]
- [[Help-Desk-Implementation]]
- [[KB-agent]]
- [[Leads]]
- [[Leads-agent]]
- [[M365-Tune-Up]]
- [[Managed-IT-Support]]
- [[Marketing]]
- [[OPS-agent]]
- [[Office-Move]]
- [[Operations]]
- [[Overflow-Support-Pilot]]
- [[Partners]]
- [[Quick-Win-Sprint]]
- [[RULES]]
- [[STACK]]
- [[Sales]]
- [[VOICE]]
- [[Website-Intake-Fix]]
- [[Workflow-Audit]]
- [[YouTube-Channel-Plan]]
- [[_ARIA]]
- [[_Amygdala]]
- [[_Brainstem]]
- [[_Campaigns]]
- [[_CorpusCa