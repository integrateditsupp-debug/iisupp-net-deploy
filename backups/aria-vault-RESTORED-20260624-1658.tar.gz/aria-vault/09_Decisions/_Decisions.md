---
brain_region: frontal-decisions
---

# Decisions log

> One note per decision. Filename `D-YYYYMMDD-short-slug.md` using `06_Templates/Decision.md`.

## Recent
- 2026-06-24 — Vault corruption → recovery (postmortem; locked R16/R17) → [[D-20260624-vault-corruption-recovery]]
- 2026-06-24 — ARIA web + Sentinel = one product, one brain → [[D-20260624-aria-web-sentinel-one-product]]
- 2026-06-23 — Director Safe-Autonomy Mandate → [[D-20260623-director-safe-autonomy-mandate]]
- 2026-06-19 — Bake Stripe price IDs in code (Rule 10) → [[D-20260619-bake-stripe-price-ids-in-code]]

## Related

<!-- LINK-WEB:auto -->
- [[AXIS]]
- [[Ahmad]]
- [[Backup-agent]]
- [[Brain-Map]]
- [[Claude-Code