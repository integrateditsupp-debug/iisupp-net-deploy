---
brain_region: frontal-decisions
type: decision
date: 2026-06-23
status: locked
---

# D-20260623 · Director Safe-Autonomy Mandate

> Recreated 2026-06-24 from session memory (original lost in the vault-corruption incident — see [[D-20260624-vault-corruption-recovery]]).

## Context
- Ahmad runs hands-on while [[Cowork]] directs the agent mesh. Waiting for restated instructions on every safe step wastes time.
- Ahmad, 2026-06-23: *"Allow director agent to make changes without any damage to company efforts, workflow, process, revenue, reputation, progress, procedures, strategies, and any other things I am missing."* + **traces ON (continuous).**

## Decision
- [[Cowork]] (director) is **authorised to act autonomously** on safe, reversible, value-additive work without re-asking — driving the queue, memory, and command files toward revenue. #important
- Every action is **traced** to the vault (daily notes + [[Live-Operations-Log]]) so Ahmad has a continuous audit trail.

## Hard guardrails (unchanged — these still bind)
- **No external sends / submissions / supplier registrations / account creation / payments / paid APIs** without Ahmad approval.
- **No risky production publish, no deletion of data, no access/permission changes** without Ahmad approval.
- No fake metrics, fake partnerships, fake testimonials, copied products, spam, or scraping against rules.
- No legal/compliance claims; **no Raymond James involvement**.
- All [[RULES]] (R1–R17) remain in force — autonomy operates *inside* the rules, never around them.

## Why
- Speed of execution > waiting for permission on reversible work; the queue + memory already define the next safe step.
- "No damage" is enforced by the guardrails + reversibility + tracing, not by withholding action.

## What this commits us to
- Director proceeds on safe work and reports concisely; Ahmad keeps approval authority over the guardrail set above.
- Anything ambiguous or irreversible → surface to Ahmad first.

## Revisit when
- Ahmad narrows/widens scope, or a guardrail needs to change.

## Related

<!-- LINK-WEB:auto -->
- [[2026-06-23]]
- [[2026-06-24]]
- [[Ahmad]]
- [[Cowork]]
- [[Claude-Code]]
- [[DIRECTOR_AUTONOMY]]
- [[D-20260624-vault-corruption-recovery]]
- [[Live-Operations-Log]]
- [[RULES]]
- [[_Decisions]]
- [[_HOME]]
<!-- /LINK-WEB:auto -->
