const messages = document.getElementById("messages");
const userInput = document.getElementById("userInput");
const sendMessage = document.getElementById("sendMessage");

function addMessage(role, text) {
  const div = document.createElement("div");
  div.className = `message ${role}`;
  div.textContent = text;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
}

function addHtmlMessage(role, html) {
  const div = document.createElement("div");
  div.className = `message ${role}`;
  div.innerHTML = html;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
}

async function sendPrompt() {
  const text = userInput.value.trim();
  if (!text) return;
  userInput.value = "";
  addMessage("user", text);
  try {
    const res = await chrome.runtime.sendMessage({
      type: "ARIA_QUERY",
      payload: text,
    });
    if (res && res.html) addHtmlMessage("aria", res.html);
    else addMessage("aria", (res && res.text) || "ARIA could not respond right now.");
  } catch (err) {
    addMessage("aria", "ARIA could not respond right now.");
  }
}

sendMessage.addEventListener("click", sendPrompt);
userInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") sendPrompt();
});

document.getElementById("addReminder").addEventListener("click", async () => {
  const title = prompt("Reminder title:");
  if (!title) return;
  const minutes = Number(prompt("Remind you in how many minutes?", "15"));
  if (!minutes || minutes < 1) return;
  await chrome.runtime.sendMessage({
    type: "ADD_REMINDER",
    payload: { title, minutes, isPrivate: true },
  });
  addMessage("aria", `Reminder set — I'll quietly let you know in ${minutes} minute${minutes === 1 ? "" : "s"}.`);
});

document.getElementById("summarizePage").addEventListener("click", async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.url) {
      addMessage("aria", "No active page found.");
      return;
    }
    const res = await chrome.runtime.sendMessage({
      type: "ARIA_QUERY",
      payload: `summarize page ${tab.url}`,
    });
    if (res && res.html) addHtmlMessage("aria", res.html);
    else addMessage("aria", (res && res.text) || "Could not summarize.");
  } catch {
    addMessage("aria", "Summarize is unavailable on this page.");
  }
});

document.getElementById("comparePrices").addEventListener("click", async () => {
  const q = prompt("What are you shopping for?");
  if (!q) return;
  addMessage("user", `Compare prices: ${q}`);
  const res = await chrome.runtime.sendMessage({
    type: "ARIA_QUERY",
    payload: `compare price ${q}`,
  });
  if (res && res.html) addHtmlMessage("aria", res.html);
  else addMessage("aria", (res && res.text) || "No result.");
});

document.getElementById("openSite").addEventListener("click", () => {
  chrome.tabs.create({ url: "https://iisupport.net/aria.html" });
});

addMessage("aria", "Hi — I'm ARIA. Ask me a question, or use the quick actions above.");
